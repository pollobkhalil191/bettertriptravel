import HomePage from "@/components/HomePage/HomePage";



export default function Home() {
  return (
   
      <main className="">
      <HomePage/>
      
      </main>
     
   
  );
}
